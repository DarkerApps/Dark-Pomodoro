import { createFileRoute } from "@tanstack/react-router";

import { FocusClock } from "@/components/focus-clock";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AMOLED Pomodoro — pitch-black focus clock" },
      {
        name: "description",
        content:
          "A minimal pomodoro timer for AMOLED screens: true black, tap anywhere to start or pause, burn-in pixel shift and quiet daily stats.",
      },
      { property: "og:title", content: "AMOLED Pomodoro — pitch-black focus clock" },
      {
        property: "og:description",
        content:
          "Tap-anywhere pomodoro timer with burn-in protection, cycle tracking and local daily stats.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <FocusClock />;
}
