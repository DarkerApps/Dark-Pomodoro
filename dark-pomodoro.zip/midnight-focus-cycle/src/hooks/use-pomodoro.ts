import { useCallback, useEffect, useReducer, useRef, useState } from "react";

import { playChime, unlockAudio } from "@/lib/chime";
import {
  formatClock,
  initialState,
  MODE_NAME,
  parseState,
  pomodoroReducer,
  sanitizeTag,
  todayKey,
  type Mode,
} from "@/lib/pomodoro";
import { useWakeLock } from "./use-wake-lock";

const STATE_KEY = "amoled-pomodoro:timer";
const TAG_KEY = "amoled-pomodoro:tag";
const MUTED_KEY = "amoled-pomodoro:muted";
const DEFAULT_TAG = "deep-work";

function read(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}
function write(key: string, value: string) {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    // Storage full or blocked — keep working in memory.
  }
}

export function usePomodoro() {
  const [state, dispatch] = useReducer(pomodoroReducer, undefined, initialState);
  const [tag, setTagState] = useState(DEFAULT_TAG);
  const [muted, setMuted] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const mutedRef = useRef(muted);
  mutedRef.current = muted;

  // Restore saved timer, tag and sound setting after hydration.
  useEffect(() => {
    const saved = parseState(read(STATE_KEY));
    if (saved) dispatch({ type: "hydrate", state: saved });
    const savedTag = read(TAG_KEY);
    if (savedTag !== null) setTagState(sanitizeTag(savedTag));
    setMuted(read(MUTED_KEY) === "1");
    dispatch({ type: "tick", now: Date.now(), today: todayKey() });
    setHydrated(true);
  }, []);

  // Persist on meaningful changes only (not every second).
  const { mode, status, endsAt, completedInSet, lastFinished, stats, remainingMs } = state;
  const persistRemaining = status === "running" ? 0 : remainingMs;
  useEffect(() => {
    if (!hydrated) return;
    write(
      STATE_KEY,
      JSON.stringify({
        mode,
        status,
        endsAt,
        completedInSet,
        lastFinished,
        stats,
        remainingMs: persistRemaining,
      }),
    );
  }, [hydrated, mode, status, endsAt, completedInSet, lastFinished, stats, persistRemaining]);

  // Tick exactly when the displayed second changes — one wake-up per second, nothing more.
  useEffect(() => {
    if (status !== "running" || endsAt == null) return;
    let id: number | undefined;
    const tick = () => dispatch({ type: "tick", now: Date.now(), today: todayKey() });
    const loop = () => {
      tick();
      const left = endsAt - Date.now();
      if (left > 0) id = window.setTimeout(loop, (left % 1000 || 1000) + 8);
    };
    const firstLeft = endsAt - Date.now();
    id = window.setTimeout(loop, firstLeft > 0 ? (firstLeft % 1000 || 1000) + 8 : 0);
    const onVisible = () => {
      if (document.visibilityState === "visible") tick();
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.clearTimeout(id);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [status, endsAt]);

  // Chime when a session runs out.
  const lastChime = useRef(state.finishCount);
  useEffect(() => {
    if (state.finishCount === lastChime.current) return;
    lastChime.current = state.finishCount;
    if (!mutedRef.current) playChime();
  }, [state.finishCount]);

  useWakeLock(status === "running");

  // Tab title shows the countdown while a session is under way.
  const clock = formatClock(remainingMs);
  useEffect(() => {
    document.title = status === "idle" ? "AMOLED Pomodoro" : `${clock} · ${MODE_NAME[mode]}`;
  }, [clock, status, mode]);

  const toggle = useCallback(() => {
    unlockAudio();
    dispatch({ type: "toggle", now: Date.now() });
  }, []);
  const reset = useCallback(() => dispatch({ type: "reset" }), []);
  const select = useCallback((m: Mode) => dispatch({ type: "select", mode: m }), []);
  const setTag = useCallback((raw: string) => {
    const clean = sanitizeTag(raw);
    setTagState(clean);
    write(TAG_KEY, clean);
  }, []);
  const toggleMuted = useCallback(() => {
    const next = !mutedRef.current;
    setMuted(next);
    write(MUTED_KEY, next ? "1" : "0");
    if (!next) playChime([880]);
  }, []);

  return { state, clock, tag, setTag, muted, toggleMuted, toggle, reset, select };
}
