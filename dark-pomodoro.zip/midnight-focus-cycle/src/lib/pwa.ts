// The only place the offline service worker is registered. vite-plugin-pwa generates /sw.js
// at build time (generateSW); it never injects its own registration.

export const SW_URL = "/sw.js";
// Must match the navigation runtimeCaching cacheName in vite.config.ts.
export const PAGES_CACHE = "focus-pages";

const PREVIEW_DOMAINS = [".lovable.app", ".gpt-eng.com", ".gptengineer.run"];
const PREVIEW_LABEL = /^(?:id-preview|preview)(?:-[a-z0-9]+)?--.+$/;
const DEV_PROJECT_LABEL = /^project--[a-z0-9-]+-dev$/;
const EDITOR_HOSTS = ["lovableproject.com", "lovableproject-dev.com", "beta.lovable.dev"];

export type SwContext = {
  isProd: boolean;
  inIframe: boolean;
  hostname: string;
  search: string;
};

/** True only on a real published origin (lovable.app main URL or a custom domain). */
export function shouldRegisterServiceWorker(ctx: SwContext): boolean {
  if (!ctx.isProd || ctx.inIframe) return false;
  if (new URLSearchParams(ctx.search).get("sw") === "off") return false;

  const host = ctx.hostname.toLowerCase();
  if (EDITOR_HOSTS.some((h) => host === h || host.endsWith(`.${h}`))) return false;

  const domain = PREVIEW_DOMAINS.find((d) => host.endsWith(d));
  if (domain) {
    const label = host.split(".")[0] ?? "";
    if (PREVIEW_LABEL.test(label) || DEV_PROJECT_LABEL.test(label)) return false;
  }
  return true;
}

function isInIframe(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

async function unregisterAppWorkers(): Promise<void> {
  const regs = await navigator.serviceWorker.getRegistrations();
  await Promise.allSettled(
    regs
      .filter((r) => {
        const url = r.active?.scriptURL ?? r.waiting?.scriptURL ?? r.installing?.scriptURL ?? "";
        return url.endsWith(SW_URL);
      })
      .map((r) => r.unregister()),
  );
}

/** Call once after hydration. */
export async function setupServiceWorker(): Promise<void> {
  if (typeof window === "undefined" || !("serviceWorker" in navigator)) return;

  const ok = shouldRegisterServiceWorker({
    isProd: import.meta.env.PROD,
    inIframe: isInIframe(),
    hostname: window.location.hostname,
    search: window.location.search,
  });

  if (!ok) {
    await unregisterAppWorkers().catch(() => undefined);
    return;
  }

  try {
    await navigator.serviceWorker.register(SW_URL, { scope: "/" });
    await navigator.serviceWorker.ready;
    // The first page load happens before the worker exists, so store the start page now
    // so the app also opens offline on the very next launch.
    if ("caches" in window) {
      const cache = await caches.open(PAGES_CACHE);
      if (!(await cache.match("/"))) await cache.add("/");
    }
  } catch (error) {
    console.warn("Service worker setup failed", error);
  }
}
