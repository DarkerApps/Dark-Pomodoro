export type Mode = "focus" | "break" | "long";
export type Status = "idle" | "running" | "paused";

export const MODES: Mode[] = ["focus", "break", "long"];
export const MODE_MINUTES: Record<Mode, number> = { focus: 25, break: 5, long: 15 };
export const MODE_CHIP: Record<Mode, string> = {
  focus: "Focus 25m",
  break: "Break 5m",
  long: "Long 15m",
};
export const MODE_NAME: Record<Mode, string> = {
  focus: "Focus",
  break: "Break",
  long: "Long break",
};
export const SESSIONS_PER_SET = 4;

export const durationMs = (mode: Mode) => MODE_MINUTES[mode] * 60_000;

export interface DayStats {
  day: string;
  sessions: number;
  focusMinutes: number;
}

export interface PomodoroState {
  mode: Mode;
  status: Status;
  /** Time left when not running; snapshot of the last tick while running. */
  remainingMs: number;
  /** Wall-clock end time while running, else null. */
  endsAt: number | null;
  /** Focus sessions finished in the current set of 4. */
  completedInSet: number;
  /** Mode that just ran out, used for the "what's next" cue; cleared on any user action. */
  lastFinished: Mode | null;
  /** Increments every time a session runs out (drives the chime). */
  finishCount: number;
  stats: DayStats;
}

export type Action =
  | { type: "toggle"; now: number }
  | { type: "reset" }
  | { type: "select"; mode: Mode }
  | { type: "tick"; now: number; today: string }
  | { type: "hydrate"; state: PomodoroState };

export function todayKey(date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function initialState(): PomodoroState {
  return {
    mode: "focus",
    status: "idle",
    remainingMs: durationMs("focus"),
    endsAt: null,
    completedInSet: 0,
    lastFinished: null,
    finishCount: 0,
    stats: { day: "", sessions: 0, focusMinutes: 0 },
  };
}

export function statsForToday(stats: DayStats, today: string): DayStats {
  return stats.day === today ? stats : { day: today, sessions: 0, focusMinutes: 0 };
}

function idleIn(state: PomodoroState, mode: Mode): PomodoroState {
  return {
    ...state,
    mode,
    status: "idle",
    remainingMs: durationMs(mode),
    endsAt: null,
    lastFinished: null,
  };
}

export function completeSession(state: PomodoroState, today: string): PomodoroState {
  let stats = statsForToday(state.stats, today);
  let completed = state.completedInSet;
  let next: Mode;
  if (state.mode === "focus") {
    stats = {
      ...stats,
      sessions: stats.sessions + 1,
      focusMinutes: stats.focusMinutes + MODE_MINUTES.focus,
    };
    completed = Math.min(completed + 1, SESSIONS_PER_SET);
    next = completed >= SESSIONS_PER_SET ? "long" : "break";
  } else {
    if (state.mode === "long") completed = 0;
    next = "focus";
  }
  return {
    ...idleIn(state, next),
    completedInSet: completed,
    lastFinished: state.mode,
    finishCount: state.finishCount + 1,
    stats,
  };
}

export function pomodoroReducer(state: PomodoroState, action: Action): PomodoroState {
  switch (action.type) {
    case "toggle":
      if (state.status === "running") {
        const left = Math.max(0, (state.endsAt ?? action.now) - action.now);
        return { ...state, status: "paused", remainingMs: left, endsAt: null };
      }
      return {
        ...state,
        status: "running",
        endsAt: action.now + state.remainingMs,
        lastFinished: null,
      };
    case "reset":
      return idleIn(state, state.mode);
    case "select": {
      const next = idleIn(state, action.mode);
      // Starting focus again after a full set without the long break begins a new set.
      if (action.mode === "focus" && state.completedInSet >= SESSIONS_PER_SET)
        next.completedInSet = 0;
      return next;
    }
    case "tick": {
      if (state.status !== "running" || state.endsAt == null) return state;
      const left = state.endsAt - action.now;
      if (left <= 0) return completeSession(state, action.today);
      return { ...state, remainingMs: left };
    }
    case "hydrate":
      return { ...action.state, finishCount: state.finishCount };
  }
}

/** Cycle label + pip states (filled = done, current = outlined bright, rest = outlined dim). */
export function cycleView(state: PomodoroState) {
  const filled = state.completedInSet;
  const current =
    state.mode === "focus" ? Math.min(filled + 1, SESSIONS_PER_SET) : Math.max(filled, 1);
  const pips = Array.from({ length: SESSIONS_PER_SET }, (_, i) =>
    i < filled ? "done" : i === current - 1 ? "current" : "todo",
  ) as Array<"done" | "current" | "todo">;
  return { label: `Cycle ${current} of ${SESSIONS_PER_SET}`, pips };
}

export function formatClock(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function formatMinutes(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m}m`;
  return m === 0 ? `${h}h` : `${h}h ${m}m`;
}

export function todayLine(stats: DayStats): string {
  if (stats.sessions === 0) return "Today: no sessions yet";
  const noun = stats.sessions === 1 ? "session" : "sessions";
  return `Today: ${stats.sessions} ${noun} (${formatMinutes(stats.focusMinutes)})`;
}

export function cueText(state: PomodoroState): string {
  if (state.status === "running") return "Tap anywhere to pause";
  if (state.status === "paused") return "Paused · tap anywhere to resume";
  if (state.lastFinished === "focus") {
    return state.mode === "long"
      ? "Set complete · tap to start long break"
      : "Focus done · tap to start break";
  }
  if (state.lastFinished) return "Break over · tap to start focus";
  return "Tap anywhere to start";
}

export function progressOf(state: PomodoroState): number {
  const total = durationMs(state.mode);
  return Math.min(1, Math.max(0, 1 - state.remainingMs / total));
}

export function sanitizeTag(raw: string): string {
  return raw
    .trim()
    .replace(/^#+/, "")
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9\-_]/g, "")
    .slice(0, 24);
}

/** Parse persisted state defensively; anything unexpected falls back to a fresh timer. */
export function parseState(raw: string | null): PomodoroState | null {
  if (!raw) return null;
  try {
    const s = JSON.parse(raw) as Partial<PomodoroState>;
    if (!s || !MODES.includes(s.mode as Mode)) return null;
    if (!["idle", "running", "paused"].includes(s.status as string)) return null;
    const base = initialState();
    const mode = s.mode as Mode;
    const remaining = typeof s.remainingMs === "number" ? s.remainingMs : durationMs(mode);
    const stats = s.stats;
    return {
      ...base,
      mode,
      status: s.status as Status,
      remainingMs: Math.min(Math.max(0, remaining), durationMs(mode)),
      endsAt: s.status === "running" && typeof s.endsAt === "number" ? s.endsAt : null,
      completedInSet: Math.min(Math.max(0, Number(s.completedInSet) || 0), SESSIONS_PER_SET),
      lastFinished: MODES.includes(s.lastFinished as Mode) ? (s.lastFinished as Mode) : null,
      stats:
        stats && typeof stats.day === "string"
          ? {
              day: stats.day,
              sessions: Math.max(0, Number(stats.sessions) || 0),
              focusMinutes: Math.max(0, Number(stats.focusMinutes) || 0),
            }
          : base.stats,
    };
  } catch {
    return null;
  }
}
