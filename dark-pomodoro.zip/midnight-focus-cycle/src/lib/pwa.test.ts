import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, expect, it } from "vitest";

import { shouldRegisterServiceWorker, type SwContext } from "./pwa";

const root = path.resolve(__dirname, "../..");
const manifest = JSON.parse(readFileSync(path.join(root, "public/manifest.json"), "utf8"));

function pngSize(publicPath: string): string {
  const buf = readFileSync(path.join(root, "public", publicPath));
  return `${buf.readUInt32BE(16)}x${buf.readUInt32BE(20)}`;
}

describe("web app manifest", () => {
  it("uses the chosen app name and short name", () => {
    expect(manifest.name).toBe("Midnight Focus Cycle");
    expect(manifest.short_name).toBe("Midnight Focus");
  });

  it("opens standalone at / on pure black", () => {
    expect(manifest.display).toBe("standalone");
    expect(manifest.start_url).toBe("/");
    expect(manifest.theme_color).toBe("#000000");
    expect(manifest.background_color).toBe("#000000");
  });

  it("ships real 192 and 512 PNG icons, both as any and maskable", () => {
    for (const purpose of ["any", "maskable"]) {
      for (const size of ["192x192", "512x512"]) {
        const icon = manifest.icons.find(
          (i: { purpose: string; sizes: string }) => i.purpose === purpose && i.sizes === size,
        );
        expect(icon, `${purpose} ${size}`).toBeDefined();
        expect(pngSize(icon.src)).toBe(size);
      }
    }
  });
});

describe("service worker registration guard", () => {
  const live: SwContext = {
    isProd: true,
    inIframe: false,
    hostname: "midnight-focus-cycle.lovable.app",
    search: "",
  };

  it("registers on the published site", () => {
    expect(shouldRegisterServiceWorker(live)).toBe(true);
    expect(shouldRegisterServiceWorker({ ...live, hostname: "focus.example.com" })).toBe(true);
  });

  it("never registers in dev, inside the editor frame, or with ?sw=off", () => {
    expect(shouldRegisterServiceWorker({ ...live, isProd: false })).toBe(false);
    expect(shouldRegisterServiceWorker({ ...live, inIframe: true })).toBe(false);
    expect(shouldRegisterServiceWorker({ ...live, search: "?sw=off" })).toBe(false);
  });

  it("never registers on Lovable preview hosts", () => {
    for (const hostname of [
      "id-preview--711a446f-da6c-43f4-9c5b-913c2355f78a.lovable.app",
      "preview--midnight-focus-cycle.lovable.app",
      "project--711a446f-da6c-43f4-9c5b-913c2355f78a-dev.lovable.app",
      "711a446f-da6c-43f4-9c5b-913c2355f78a.lovableproject.com",
      "beta.lovable.dev",
    ]) {
      expect(shouldRegisterServiceWorker({ ...live, hostname }), hostname).toBe(false);
    }
  });
});
