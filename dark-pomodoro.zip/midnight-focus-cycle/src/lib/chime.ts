// Tiny synthesized chime: no audio files to download, and the context is
// suspended again right after so it costs nothing while idle.
let ctx: AudioContext | null = null;
let suspendTimer: number | undefined;

function getContext(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const Ctor =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    ctx = new Ctor();
  }
  return ctx;
}

/** Call from a tap/keypress so mobile browsers allow sound later. */
export function unlockAudio() {
  const c = getContext();
  if (c && c.state === "suspended") void c.resume().then(() => scheduleSuspend(c, 300));
}

function scheduleSuspend(c: AudioContext, delay: number) {
  window.clearTimeout(suspendTimer);
  suspendTimer = window.setTimeout(() => void c.suspend().catch(() => {}), delay);
}

export function playChime(notes: number[] = [659.25, 880, 1318.5]) {
  const c = getContext();
  if (!c) return;
  void c.resume().then(() => {
    const start = c.currentTime + 0.02;
    notes.forEach((freq, i) => {
      const t = start + i * 0.22;
      const osc = c.createOscillator();
      const gain = c.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, t);
      gain.gain.exponentialRampToValueAtTime(0.14, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 1.1);
      osc.connect(gain).connect(c.destination);
      osc.start(t);
      osc.stop(t + 1.2);
    });
    scheduleSuspend(c, notes.length * 220 + 1400);
  });
}
