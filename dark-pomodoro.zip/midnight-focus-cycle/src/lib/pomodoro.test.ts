import { describe, expect, it } from "vitest";
import {
  completeSession,
  cycleView,
  formatClock,
  initialState,
  pomodoroReducer,
  statsForToday,
  todayLine,
  type PomodoroState,
} from "./pomodoro";

const DAY = "2026-11-19";

function finishFocus(state: PomodoroState, today = DAY) {
  return completeSession({ ...state, mode: "focus" }, today);
}

describe("pomodoro rules", () => {
  it("presets are 25, 5 and 15 minutes", () => {
    const s = initialState();
    expect(formatClock(s.remainingMs)).toBe("25:00");
    expect(formatClock(pomodoroReducer(s, { type: "select", mode: "break" }).remainingMs)).toBe(
      "05:00",
    );
    expect(formatClock(pomodoroReducer(s, { type: "select", mode: "long" }).remainingMs)).toBe(
      "15:00",
    );
  });

  it("a finished focus session leads to a short break", () => {
    const next = finishFocus(initialState());
    expect(next.mode).toBe("break");
    expect(next.status).toBe("idle");
  });

  it("the 4th finished focus session leads to the long break", () => {
    let s = initialState();
    for (let i = 0; i < 3; i++) s = completeSession(finishFocus(s), DAY); // focus + break
    expect(s.completedInSet).toBe(3);
    s = finishFocus(s);
    expect(s.mode).toBe("long");
    expect(cycleView(s).label).toBe("Cycle 4 of 4");
  });

  it("finishing the long break starts a new set at cycle 1", () => {
    const s = completeSession({ ...initialState(), mode: "long", completedInSet: 4 }, DAY);
    expect(s.mode).toBe("focus");
    expect(cycleView(s).label).toBe("Cycle 1 of 4");
  });

  it("shows cycle 2 of 4 with one pip done during the second focus", () => {
    const view = cycleView({ ...initialState(), completedInSet: 1 });
    expect(view.label).toBe("Cycle 2 of 4");
    expect(view.pips).toEqual(["done", "current", "todo", "todo"]);
  });

  it("counts only focus sessions in today's stats: 4 sessions is 1h 40m", () => {
    let s = initialState();
    for (let i = 0; i < 4; i++) s = completeSession(finishFocus(s), DAY);
    expect(todayLine(s.stats)).toBe("Today: 4 sessions (1h 40m)");
  });

  it("stats start over on a new day", () => {
    const s = finishFocus(initialState(), DAY);
    expect(statsForToday(s.stats, "2026-11-20").sessions).toBe(0);
    expect(finishFocus(s, "2026-11-20").stats.sessions).toBe(1);
  });

  it("pausing keeps the time left and resuming continues from it", () => {
    let s = pomodoroReducer(initialState(), { type: "toggle", now: 0 });
    s = pomodoroReducer(s, { type: "toggle", now: 2_000 });
    expect(s.status).toBe("paused");
    expect(formatClock(s.remainingMs)).toBe("24:58");
    s = pomodoroReducer(s, { type: "toggle", now: 100_000 });
    expect(s.endsAt).toBe(100_000 + 24 * 60_000 + 58_000);
  });

  it("a running timer completes when its end time passes", () => {
    let s = pomodoroReducer(initialState(), { type: "toggle", now: 0 });
    s = pomodoroReducer(s, { type: "tick", now: 25 * 60_000, today: DAY });
    expect(s.mode).toBe("break");
    expect(s.stats.sessions).toBe(1);
    expect(s.finishCount).toBe(1);
  });
});
