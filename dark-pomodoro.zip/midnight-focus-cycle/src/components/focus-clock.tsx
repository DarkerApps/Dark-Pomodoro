import {
  useEffect,
  useRef,
  useState,
  type KeyboardEvent as ReactKeyboardEvent,
  type MouseEvent,
} from "react";
import { RotateCcw, Volume2, VolumeX } from "lucide-react";

import { usePomodoro } from "@/hooks/use-pomodoro";
import { cn } from "@/lib/utils";
import {
  cueText,
  cycleView,
  MODE_CHIP,
  MODES,
  progressOf,
  statsForToday,
  todayKey,
  todayLine,
  type Mode,
} from "@/lib/pomodoro";

/** Stop a control's tap from also toggling the timer, and drop focus so Space keeps meaning start/pause. */
function control(fn: () => void) {
  return (e: MouseEvent<HTMLElement>) => {
    e.stopPropagation();
    fn();
    e.currentTarget.blur();
  };
}

const focusRing =
  "focus-visible:outline focus-visible:outline-1 focus-visible:outline-offset-2 focus-visible:outline-ink";

export function FocusClock() {
  const p = usePomodoro();
  const { state } = p;
  const running = state.status === "running";
  const cycle = cycleView(state);
  const progress = progressOf(state);
  // Desktop shortcuts: Space start/pause, R reset, 1/2/3 modes, M sound.
  const { toggle, reset, select, toggleMuted } = p;
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.isContentEditable)) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const k = e.key.toLowerCase();
      if (e.code === "Space" || k === " ") {
        e.preventDefault();
        if (!e.repeat) toggle();
      } else if (k === "r") reset();
      else if (k === "m") toggleMuted();
      else if (k === "1" || k === "2" || k === "3") select(MODES[Number(k) - 1] as Mode);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggle, reset, select, toggleMuted]);

  const stats = statsForToday(state.stats, todayKey());
  const showReset = state.status !== "idle" || progress > 0;

  return (
    <div
      className="fixed inset-0 flex cursor-pointer touch-manipulation flex-col overflow-hidden bg-background font-mono text-ink select-none"
      onClick={toggle}
    >
      {/* 1px session progress hairline */}
      <div className="h-px w-full shrink-0 bg-line" aria-hidden>
        <div
          className="h-px w-full origin-left bg-ink"
          style={{ transform: `scaleX(${progress})` }}
        />
      </div>

      <div className="shift safe-pad flex flex-1 flex-col px-6 pt-6 pb-6 md:px-12 md:pt-10 md:pb-10">
        <header className="flex items-center justify-between gap-4 text-[13px] tracking-wide text-meta md:text-[15px]">
          <span className="min-w-0 text-[13px] text-meta md:text-[15px]">DarkerApps</span>
          <span className="flex shrink-0 items-center gap-2" aria-label={cycle.label}>
            <span className="flex gap-1.5" aria-hidden>
              {cycle.pips.map((pip, i) => (
                <span
                  key={i}
                  className={cn(
                    "h-1.5 w-1.5 rounded-full",
                    pip === "done" && "bg-ink",
                    pip === "current" && "border border-ink",
                    pip === "todo" && "border border-dim",
                  )}
                />
              ))}
            </span>
            {cycle.label}
          </span>
        </header>

        <main className="flex flex-1 flex-col items-center justify-center">
          <div className="relative flex flex-col items-center">
            <h1 className="clock-digits leading-none font-extralight tracking-[-0.05em] tabular-nums text-ink">
              <span className="sr-only">Time left </span>
              {p.clock}
            </h1>
            <p
              className="mt-8 text-[12px] tracking-wide text-dim md:text-[14px]"
              aria-live="polite"
            >
              {cueText(state)}
            </p>
            {!running && (
              <div className="absolute top-full left-1/2 mt-6 flex -translate-x-1/2 gap-2 whitespace-nowrap">
                {showReset && (
                  <button
                    type="button"
                    onClick={control(p.reset)}
                    className={cn(
                      "inline-flex h-11 items-center gap-2 rounded-full border border-line px-5 text-[12px] tracking-wide text-dim",
                      focusRing,
                    )}
                  >
                    <RotateCcw className="h-3.5 w-3.5" strokeWidth={1.4} aria-hidden />
                    Reset
                  </button>
                )}
                <button
                  type="button"
                  onClick={control(p.toggleMuted)}
                  aria-pressed={!p.muted}
                  className={cn(
                    "inline-flex h-11 items-center gap-2 rounded-full border border-line px-5 text-[12px] tracking-wide text-dim",
                    focusRing,
                  )}
                >
                  {p.muted ? (
                    <VolumeX className="h-3.5 w-3.5" strokeWidth={1.4} aria-hidden />
                  ) : (
                    <Volume2 className="h-3.5 w-3.5" strokeWidth={1.4} aria-hidden />
                  )}
                  {p.muted ? "Sound off" : "Sound on"}
                </button>
              </div>
            )}
          </div>
        </main>

        <nav
          className="mx-auto flex w-full max-w-xl gap-2 text-[12px] tabular-nums md:text-[13px]"
          aria-label="Timer mode"
        >
          {MODES.map((m: Mode) => {
            const active = state.mode === m;
            return (
              <button
                key={m}
                type="button"
                onClick={control(() => p.select(m))}
                aria-pressed={active}
                className={cn(
                  "grid h-11 place-items-center rounded-full border md:h-12",
                  m === "long" ? "flex-[1.3]" : "flex-1",
                  active ? "border-faint bg-faint text-ink" : "border-line text-dim",
                  focusRing,
                )}
              >
                {MODE_CHIP[m]}
              </button>
            );
          })}
        </nav>

        <footer className="mt-6 text-center text-[11px] tracking-wide text-faint md:text-[12px]">
          {todayLine(stats)} · Pixel shift active
        </footer>
      </div>
    </div>
  );
}

function TagField({ tag, onChange }: { tag: string; onChange: (raw: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(tag);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editing) inputRef.current?.select();
  }, [editing]);

  const commit = () => {
    onChange(draft);
    setEditing(false);
  };

  if (editing) {
    return (
      <span className="flex min-w-0 items-center" onClick={(e) => e.stopPropagation()}>
        <span aria-hidden>#</span>
        <input
          ref={inputRef}
          value={draft}
          maxLength={24}
          aria-label="Task tag"
          placeholder="tag"
          autoCapitalize="none"
          autoCorrect="off"
          spellCheck={false}
          enterKeyHint="done"
          onChange={(e) => setDraft(e.target.value)}
          onBlur={commit}
          onKeyDown={(e: ReactKeyboardEvent<HTMLInputElement>) => {
            if (e.key === "Enter") e.currentTarget.blur();
            if (e.key === "Escape") {
              setDraft(tag);
              setEditing(false);
            }
          }}
          className="w-[16ch] min-w-0 border-b border-line bg-transparent text-ink caret-ink outline-none placeholder:text-dim"
        />
      </span>
    );
  }

  return (
    <button
      type="button"
      onClick={control(() => {
        setDraft(tag);
        setEditing(true);
      })}
      aria-label={tag ? `Tag #${tag}, tap to edit` : "Add a tag"}
      className={cn("min-w-0 truncate text-left", tag ? "text-meta" : "text-dim", focusRing)}
    >
      {tag ? `#${tag}` : "#add-tag"}
    </button>
  );
}
