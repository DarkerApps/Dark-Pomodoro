<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- Timer rules live as a pure reducer in `src/lib/pomodoro.ts` (tested in `pomodoro.test.ts`); UI and hooks only dispatch actions — keeps the rules testable without a browser.
- All data (timer, tag, sound, daily stats) stays in localStorage; no backend — the app targets low-power devices and needs no accounts.
- The timer ticks with a self-scheduling timeout aligned to the next visible second, never a fast interval, and burn-in drift uses a stepped CSS animation — both to keep wake-ups and repaints minimal.
- Colours come only from the white-alpha tokens in `src/styles.css` over pure black; there is a single theme.
- Installability: the manifest is the static `public/manifest.json` (icons at the `public/` root); vite-plugin-pwa only generates the offline `/sw.js` (generateSW, `outDir: dist/client`, network-first pages) and `src/lib/pwa.ts` is the sole registrar, refusing dev, iframes and Lovable preview hosts — keeps previews free of stale caches while the published site passes PWA audits.
